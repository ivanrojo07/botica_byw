<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('WP_CACHE', true); //Added by WP-Cache Manager
define( 'WPCACHEHOME', '/home2/rxlatin1/public_html/wpshop/wp-content/plugins/wp-super-cache/' ); //Added by WP-Cache Manager
define('MMAFF', 'hostgator' ); //Added by QuickInstall

define('DB_NAME', 'rxlatin1_wrdp1');

/** MySQL database username */
define('DB_USER', 'rxlatin1_wrdp1');

/** MySQL database password */
define('DB_PASSWORD', 'hXqdEAxpZzigb');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Sc)s5<4a=k3omsyVrU2r!#|\`0-5dw<hys=8\`pR!E^zDrXz4bi:>F<YxQDXy^)9?8Z!78|IQPq:PI:n0OxyK$o/^<|I');
define('SECURE_AUTH_KEY',  '');
define('LOGGED_IN_KEY',    'ITrsOAGxBoK0FF*oAgBz2\`5CUGp;w9rH-O!hg$AaYaTJe|_>4@I!y^<gBp3!RT8hovkQp4');
define('NONCE_KEY',        ':5U7-?#v1:)ZPbID<_tGQB_F>\`8(MiY^yA99tWS\`P;O<G59hzfHPsfz5bxt?I1Qnmf*cHPFxFs(G8k');
define('AUTH_SALT',        '1J:L:!*p!R8ma>aO$R:4*5A*k>B?qS97<r/WO9HoC0C6h6Qs?48b>pE()B9OB<!25rw7t');
define('SECURE_AUTH_SALT', 'OuJwe$~@Jt@$U_ULfkCaY:E784IA3UOL)^?6$JgUu\`@q?b1P1uq1lF8?#/iKCWhiX6:I1Cc');
define('LOGGED_IN_SALT',   ':(>q|Jeqljqu|b7UwI\`2BE>RA~#q#ID7zYd_5Y|Rx4#<wE8?W)=*#dPp9m/o!f-i5Q7ceFo4yOdvT');
define('NONCE_SALT',       '!uT(YgJ-6^LARh<7C/QeDOpk;MaM58L<L$S|-9Cp*ZaEhOHw5nN!~HBjsvFvk3s2:c');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
